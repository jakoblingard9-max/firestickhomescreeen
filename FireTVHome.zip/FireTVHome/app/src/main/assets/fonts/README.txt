Drop the font files here (free from fonts.google.com, "Download family"), named exactly:
Creepster-Regular.ttf, MountainsofChristmas-Bold.ttf, Fredoka.ttf,
PlayfairDisplay.ttf, BebasNeue-Regular.ttf, Outfit.ttf
(for variable fonts, rename the file inside the zip, e.g. Fredoka[wdth,wght].ttf -> Fredoka.ttf)
Then rebuild the APK. The fonts will then work with no internet.
